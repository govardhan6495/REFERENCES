package com.loanapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendLoanapp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
